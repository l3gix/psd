// scambia due valori di due varibili 
void swap(int *a,int *b);