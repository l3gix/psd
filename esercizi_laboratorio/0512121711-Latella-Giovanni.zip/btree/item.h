typedef void* Item;

Item inputItem();
void outputItem(Item);
int cmpItem(Item, Item);
char* itemToString(Item a);
Item randomItem();