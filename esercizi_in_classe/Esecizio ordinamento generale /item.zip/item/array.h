#include "item.h"

void inputArray(Item a[], int n);
void outputArray(Item a[], int n);
void bubbleSort(Item a[], int n);

